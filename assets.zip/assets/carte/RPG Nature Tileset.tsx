<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="RPG Nature Tileset" tilewidth="32" tileheight="32" tilecount="180" columns="20">
 <image source="RPG Nature Tileset.png" width="641" height="288"/>
</tileset>
