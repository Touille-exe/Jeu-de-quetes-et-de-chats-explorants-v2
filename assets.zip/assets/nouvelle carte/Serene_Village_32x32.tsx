<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Serene_Village_32x32" tilewidth="32" tileheight="32" tilecount="855" columns="19">
 <image source="assets/Serene_Village_32x32.png" width="608" height="1440"/>
</tileset>
